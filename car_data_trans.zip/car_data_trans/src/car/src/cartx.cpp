#include <iostream>
#include <memory.h>
#include <ros/ros.h>
#include "car/car_status.h"
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/Point.h>
#include "SerialPort.h"
#include <sensor_msgs/NavSatFix.h>
#include <eigen3/Eigen/Eigen>
#include "/home/lu/lib/mavlink/common/common/mavlink.h"  // /opt/ros/noetic/include 

using namespace std;

bool receive_localmsg = false;
bool receive_globalmsg = false;
static mavlink_message_t mavlink_msg;
static mavlink_message_t mavlink_msg_tx;
static mavlink_status_t status;
static car::car_status car_msg; //tx数据
nav_msgs::Odometry mavros_odom;
SerialPort port1;
static void uart_callback(char *buff,uint16_t len)
{
	for (int i = 0; i < len; ++i) {
        if (mavlink_parse_char(MAVLINK_COMM_0, buff[i], &mavlink_msg, &status)){
			switch (mavlink_msg.msgid) {
				case MAVLINK_MSG_ID_HEARTBEAT: {
					printf("heart beat %d %d \r\n",mavlink_msg.sysid,mavlink_msg.compid);
					break;
				}
				case MAVLINK_MSG_ID_GPS_RAW_INT:
				{
					mavlink_gps_raw_int_t gps_raw_int;
					mavlink_msg_gps_raw_int_decode(&mavlink_msg,&gps_raw_int);
					// car_msg.status = gps_raw_int.fix_type;

					mavlink_hil_gps_t hil_gps;
					hil_gps.fix_type = 1;
					hil_gps.time_usec = gps_raw_int.time_usec;
					hil_gps.lat = gps_raw_int.lat;
					hil_gps.lon = gps_raw_int.lon;
					hil_gps.alt = gps_raw_int.alt;
					hil_gps.eph = gps_raw_int.eph;
					hil_gps.epv = gps_raw_int.epv;
					hil_gps.vel = gps_raw_int.vel;
					hil_gps.cog = gps_raw_int.cog;
					hil_gps.satellites_visible = UINT8_MAX;
					hil_gps.yaw = gps_raw_int.yaw;

					// uint8_t buffer[300];
					// mavlink_msg_hil_gps_encode(1,0,&mavlink_msg_tx,&hil_gps);
					// uint8_t len = mavlink_msg_to_send_buffer(buffer,&mavlink_msg_tx);
					// int32_t status = port1.write(buffer,len);
				    // printf("hil_gps TX status: %d %d %d %d\n",gps_raw_int.fix_type,gps_raw_int.lat,gps_raw_int.lon,gps_raw_int.alt);
					break;
				}
				case 33:{
					
					// std::cout<<"33 recevice" << std::endl;
					break;
				}
				case MAVLINK_MSG_ID_ODOMETRY:{
					//1. 收到里程计信息
					mavlink_odometry_t odometry;
					mavlink_msg_odometry_decode(&mavlink_msg, &odometry);
					//2. 转换为local_position_ned信息
                    car_msg.px = odometry.x;
                    car_msg.py = odometry.y;
                    car_msg.pz = odometry.z;
                    car_msg.vx = odometry.vx;
                    car_msg.vy = odometry.vy;
                    car_msg.vz = odometry.vz;
					printf("%f %f \r\n",car_msg.px,car_msg.py);
					// fprintf(file, "%u %f %f %f %f %f %f \r\n",local_position_ned.time_boot_ms, \
					//                                 local_position_ned.x,local_position_ned.y,local_position_ned.z,  \
					//                                 local_position_ned.vx,local_position_ned.vy,local_position_ned.vz );
					break;
				}
				case MAVLINK_MSG_ID_ATTITUDE: {
				    mavlink_attitude_t attitude;
				    mavlink_msg_attitude_decode(&mavlink_msg, &attitude);
                    car_msg.yaw = attitude.yaw;
                    car_msg.roll = attitude.roll;
                    car_msg.pitch = attitude.pitch;
                    car_msg.time = attitude.time_boot_ms;
                    
				//                             // 将MAVLink消息序列化到缓冲区
				//     uint16_t len = mavlink_msg_to_send_buffer(buffer, &msg);

				// // 发送缓冲区中的数据到串口
				// ssize_t bytes_sent = write(serial_txFd, buffer, len);
					break;
				}
				case MAVLINK_MSG_ID_HIGHRES_IMU: {
                    

					mavlink_highres_imu_t imu;
					mavlink_msg_highres_imu_decode(&mavlink_msg, &imu);
					break;
					// printf("Received message with ID %d, sequence: %d from component %d of system %d \r\n", msg.msgid, msg.seq, msg.compid, msg.sysid);
					// printf("xacc yacc zacc: %d: %f\t %f\t %f\r\n",imu.time_usec, imu.xacc, imu.yacc, imu.zacc);
				}
				default :
					break;
				}
		}
	}
}
static  float gps_lat=0,gps_lon=0,gps_alt=0;
double myvector[4];
static void rtk_callback(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
	sensor_msgs::NavSatFix navsat = *msg;

	// std::cout << msg->status << std::endl;
	// printf("%.8lf %.8lf %.8lf \r\n",msg->latitude,msg->longitude,msg->altitude);
	// std::cout << msg->latitude - myvector[0]<<std::endl;
	// std::cout << msg->longitude -myvector[1]<<std::endl;
	// std::cout << msg->altitude - myvector[2]<<std::endl;

	// myvector[0] = msg->latitude;
	// myvector[1] = msg->longitude;
	// myvector[2] = msg->altitude;

	mavlink_hil_gps_t hil_gps;
	car_msg.status = msg->status.status+1;
	if(msg->status.status>=0)hil_gps.fix_type = 5;
	else hil_gps.fix_type = 0;
	hil_gps.time_usec = msg->header.stamp.sec;
	hil_gps.lat = msg->latitude*10000000;
	hil_gps.lon = msg->longitude*10000000;
	hil_gps.alt = msg->altitude*1000.0f;
	// hil_gps.fix_type = 6;`
car_msg.time = hil_gps.time_usec;
	gps_lat = msg->latitude;
	gps_lon = msg->longitude;
	gps_alt = msg->altitude;

	hil_gps.satellites_visible = UINT8_MAX;
	printf("%d %d %d %d \r\n",hil_gps.lat ,hil_gps.lon ,hil_gps.alt,  msg->status.status);
	uint8_t buffer[300];
	mavlink_msg_hil_gps_encode(1,0,&mavlink_msg_tx,&hil_gps);
	uint8_t len = mavlink_msg_to_send_buffer(buffer,&mavlink_msg_tx);
	// port1.write(buffer,len);
	// std::cout << port1.write(buffer,len)<<std::endl;


}  

void mavros_callback(const nav_msgs::Odometry::ConstPtr& odomMsg)
{
	mavros_odom = *odomMsg;
	receive_localmsg = true;
}
void mavros_lalo_callback(const sensor_msgs::NavSatFix::ConstPtr& lolaMsg)
{
	gps_lat = lolaMsg->latitude;
	gps_lon = lolaMsg->longitude;
	receive_globalmsg = true;
}
// void mavros_utm_callback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& utmMsg)
// {
// 	utmpoint = utmMsg->pose.pose.position;
// 	receive_globalmsg = true;
// }

static void uart2_callback(char *buff,uint16_t len)
{
	static mavlink_message_t mavlink_msg;
	static mavlink_status_t status;
	for (int i = 0; i < len; ++i) {
        if (mavlink_parse_char(MAVLINK_COMM_0, buff[i], &mavlink_msg, &status)){
			switch (mavlink_msg.msgid) {
			case 204:
			{
				mavlink_car_status_t car;
				mavlink_msg_car_status_decode(&mavlink_msg, &car);
				static uint32_t tick = 0;
				// cout << "成功！"<< ++tick <<" "<< car.yaw <<endl;
				break;
			}
			
			
			}

		}
	}
}
void px4_heart(void)
{
	mavlink_message_t msg;
	uint8_t buffer[100];
    mavlink_msg_heartbeat_pack(1, 0, &msg, MAV_TYPE_QUADROTOR, MAV_AUTOPILOT_GENERIC, MAV_MODE_PREFLIGHT, MAVLINK_VERSION, MAV_STATE_STANDBY);

    // 将MAVLink消息序列化到缓冲区
    uint16_t len = mavlink_msg_to_send_buffer(buffer, &msg);
	// port1.write(buffer,len);
}
void QuaterniontoRPY(Eigen::Vector3d& rpy)
{
	Eigen::Quaterniond q(mavros_odom.pose.pose.orientation.w, mavros_odom.pose.pose.orientation.x,mavros_odom.pose.pose.orientation.y, mavros_odom.pose.pose.orientation.z);
	Eigen::Matrix3d rx = q.toRotationMatrix();
	rpy = rx.eulerAngles(2,1,0);
}
int main(int argc, char *argv[])
{
	ros::init(argc, argv, "cartx_node");
    ros::NodeHandle nh;


    // 1. 开启uart
	
	// port1.open("/dev/ttyACM0", SerialPort::defaultOptions);
	// if (port1.isOpen())
	// {
	// 	cout << "px4 open success!" << endl;
	// }
	// else
	// {
	// 	cout << "px4 open failed!" << endl;
	// 	return 0;
	// }
	// port1.openThread(uart_callback);
	
	SerialPort port2;
	SerialPort::OpenOptions uartOptions = SerialPort::defaultOptions;
	uartOptions.baudRate = SerialPort::BR38400;
	port2.open("/dev/ttyUSB_0",uartOptions);
	if (port2.isOpen())
	{
		cout << "send port open success!" << endl;
	}
	else
	{
		cout << "send port open failed!" << endl;
		return 0;
	}
	port2.openThread(uart2_callback);
    // //2. ros发送
    ros::Publisher pub = nh.advertise<car::car_status>("carTx", 10);
	ros::Subscriber subscriber;
	ros::Subscriber mavrosSub;
	ros::Subscriber utmSub;
	mavrosSub = nh.subscribe("/mavros/local_position/odom", 5, &mavros_callback);
	utmSub = nh.subscribe("/mavros/global_position/global", 5, &mavros_lalo_callback);
	subscriber = nh.subscribe("gps/navsat", 5, &rtk_callback);
    ros::Rate rate_hz(45);
	uint8_t gps_tick=0;
    while(ros::ok()) {
		// px4_heart();
        // 初始化消息对象
        pub.publish(car_msg);

		if(receive_globalmsg && receive_localmsg)
		{
			Eigen::Vector3d rpy;
			QuaterniontoRPY(rpy);

			mavlink_car_status_t mavlink_car_status;
			mavlink_car_status.pitch = rpy[1];
			mavlink_car_status.roll = rpy[2];
			mavlink_car_status.yaw = rpy[0];
			mavlink_car_status.px = mavros_odom.pose.pose.position.x;
			mavlink_car_status.py = mavros_odom.pose.pose.position.y;
			mavlink_car_status.pz = mavros_odom.pose.pose.position.z;
			mavlink_car_status.vx = mavros_odom.twist.twist.linear.x;
			mavlink_car_status.vy = mavros_odom.twist.twist.linear.y;
			mavlink_car_status.vz = mavros_odom.twist.twist.linear.z;
			mavlink_car_status.time_ms = mavros_odom.header.stamp.toSec();
			mavlink_car_status.status = 1;

			if(++gps_tick>5)
			{
				gps_tick =0;
				mavlink_car_status.px = gps_lat;
				mavlink_car_status.py = gps_lon;
				// mavlink_car_status.pz = gps_alt;
				mavlink_car_status.status = 11;
			}

			mavlink_msg_car_status_encode(0,0,&mavlink_msg_tx,&mavlink_car_status);
			unsigned char temp[280];
			uint8_t len = mavlink_msg_to_send_buffer(temp,&mavlink_msg_tx);
			port2.write(temp,len);
		}
		else
		{
			if(!receive_globalmsg)
				ROS_ERROR("Cannot receive global msg from PX4");

			if(!receive_localmsg)
				ROS_ERROR("Cannot receive local msg from PX4");
		}
        ros::spinOnce();
        rate_hz.sleep();
    }
	
    port2.close();//关闭串口及结束线程
	// port1.close();
	return 0;
}