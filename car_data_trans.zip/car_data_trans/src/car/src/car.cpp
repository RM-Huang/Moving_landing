#include <ros/ros.h>
#include <std_msgs/String.h>
#include "car/car_status.h"
#include "SerialPort.h"

//测试用
int main(int argc, char *argv[])
{
    ros::init(argc, argv, "chao_node");
    printf("Hello World!\n");

    // nh 负责管理话题创建，消息发送
    ros::NodeHandle nh;
    // 新建消息发送对象，确定话题名称和发送对象消息容量，这里最多可以接收10个消息，话题名称不能是中文
    ros::Publisher pub = nh.advertise<car::car_status>("Topic", 10);
    ros::Rate rate_hz(10);
    while(ros::ok()) {
        printf("ok\n");
        // 初始化消息对象
        car::car_status msg;
        msg.px = 1;
        msg.py = 2;
        msg.pz = 3;

        pub.publish(msg);
        ros::spinOnce();
        rate_hz.sleep();
    }
    return 0;
}
