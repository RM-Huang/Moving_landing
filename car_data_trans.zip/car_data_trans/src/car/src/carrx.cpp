#include <iostream>
#include <memory.h>
#include <ros/ros.h>
#include "car/car_status.h"
#include "SerialPort.h"
#include <sensor_msgs/NavSatFix.h>
#include "/home/lu/lib/mavlink/common/common/mavlink.h"  // /opt/ros/noetic/include 

using namespace std;

static mavlink_message_t mavlink_msg;
static mavlink_message_t mavlink_msg_tx;
static mavlink_status_t status;
static car::car_status car_msg; //tx数据
SerialPort port1;
static void uart_callback(char *buff,uint16_t len)
{
	for (int i = 0; i < len; ++i) {
        if (mavlink_parse_char(MAVLINK_COMM_0, buff[i], &mavlink_msg, &status)){
			switch (mavlink_msg.msgid) {
				case MAVLINK_MSG_ID_HEARTBEAT: {
					printf("heart beat %d %d \r\n",mavlink_msg.sysid,mavlink_msg.compid);
					break;
				}
				case MAVLINK_MSG_ID_GPS_RAW_INT:
				{
					mavlink_gps_raw_int_t gps_raw_int;
					mavlink_msg_gps_raw_int_decode(&mavlink_msg,&gps_raw_int);
					car_msg.status = gps_raw_int.fix_type;

					mavlink_hil_gps_t hil_gps;
					hil_gps.fix_type = 1;
					hil_gps.time_usec = gps_raw_int.time_usec;
					hil_gps.lat = gps_raw_int.lat;
					hil_gps.lon = gps_raw_int.lon;
					hil_gps.alt = gps_raw_int.alt;
					hil_gps.eph = gps_raw_int.eph;
					hil_gps.epv = gps_raw_int.epv;
					hil_gps.vel = gps_raw_int.vel;
					hil_gps.cog = gps_raw_int.cog;
					hil_gps.satellites_visible = UINT8_MAX;
					hil_gps.yaw = gps_raw_int.yaw;

					// uint8_t buffer[300];
					// mavlink_msg_hil_gps_encode(1,0,&mavlink_msg_tx,&hil_gps);
					// uint8_t len = mavlink_msg_to_send_buffer(buffer,&mavlink_msg_tx);
					// int32_t status = port1.write(buffer,len);
					printf("hil_gps TX status: %d\n",gps_raw_int.fix_type);
					break;
				}
				case 33:{
					
					std::cout<<"33 recevice" << std::endl;
					break;
				}
				case MAVLINK_MSG_ID_ODOMETRY:{
					//1. 收到里程计信息
					mavlink_odometry_t odometry;
					mavlink_local_position_ned_t local_position_ned;
					mavlink_msg_odometry_decode(&mavlink_msg, &odometry);
					//2. 转换为local_position_ned信息
                    car_msg.px = odometry.x;
                    car_msg.py = odometry.y;
                    car_msg.pz = odometry.z;
                    car_msg.vx = odometry.vx;
                    car_msg.vy = odometry.vy;
                    car_msg.vz = odometry.vz;

					local_position_ned.time_boot_ms = odometry.time_usec;
					local_position_ned.vx = odometry.vx;
					local_position_ned.vy = odometry.vy;
					local_position_ned.vz = odometry.vz;
					local_position_ned.x = odometry.x;
					local_position_ned.y = odometry.y;
					local_position_ned.z = 57.3*atan2f(2*(odometry.q[0]*odometry.q[3]+odometry.q[1]*odometry.q[2]),1-2*(odometry.q[2]*odometry.q[2]+odometry.q[3]*odometry.q[3]));
					// printf("odometry \r\n");
					// printf("%u %f %f %f %f %f %f \r\n",local_position_ned.time_boot_ms, \
					//                                 local_position_ned.x,local_position_ned.y,local_position_ned.z,  \
					//                                 local_position_ned.vx,local_position_ned.vy,local_position_ned.vz );
					// fprintf(file, "%u %f %f %f %f %f %f \r\n",local_position_ned.time_boot_ms, \
					//                                 local_position_ned.x,local_position_ned.y,local_position_ned.z,  \
					//                                 local_position_ned.vx,local_position_ned.vy,local_position_ned.vz );
					break;
				}
				case MAVLINK_MSG_ID_ATTITUDE: {
				    mavlink_attitude_t attitude;
				    mavlink_msg_attitude_decode(&mavlink_msg, &attitude);
                    car_msg.yaw = attitude.yaw;
                    car_msg.roll = attitude.roll;
                    car_msg.pitch = attitude.pitch;
                    car_msg.time = attitude.time_boot_ms;
                    
				//                             // 将MAVLink消息序列化到缓冲区
				//     uint16_t len = mavlink_msg_to_send_buffer(buffer, &msg);

				// // 发送缓冲区中的数据到串口
				// ssize_t bytes_sent = write(serial_txFd, buffer, len);
					break;
				}
				case MAVLINK_MSG_ID_HIGHRES_IMU: {
                    

					mavlink_highres_imu_t imu;
					mavlink_msg_highres_imu_decode(&mavlink_msg, &imu);
					break;
					// printf("Received message with ID %d, sequence: %d from component %d of system %d \r\n", msg.msgid, msg.seq, msg.compid, msg.sysid);
					// printf("xacc yacc zacc: %d: %f\t %f\t %f\r\n",imu.time_usec, imu.xacc, imu.yacc, imu.zacc);
				}
				default :
					break;
				}
		}
	}
}

static void rtk_callback(const sensor_msgs::NavSatFix::ConstPtr& msg)
{
	sensor_msgs::NavSatFix navsat = *msg;

	// std::cout << msg->status << std::endl;
	// std::cout << msg->latitude<<std::endl;
	// std::cout << msg->longitude<<std::endl;
	// std::cout << msg->altitude<<std::endl;

	mavlink_hil_gps_t hil_gps;

	if(msg->status.status==0)hil_gps.fix_type = 3;
	else hil_gps.fix_type = 0;
	hil_gps.time_usec = msg->header.stamp.sec;
	hil_gps.lat = msg->latitude;
	hil_gps.lon = msg->longitude;
	hil_gps.alt = msg->altitude;
	hil_gps.satellites_visible = UINT8_MAX;

	uint8_t buffer[300];
	mavlink_msg_hil_gps_encode(1,0,&mavlink_msg_tx,&hil_gps);
	uint8_t len = mavlink_msg_to_send_buffer(buffer,&mavlink_msg_tx);
	std::cout << port1.write(buffer,len)<<std::endl;


}      
static void uart2_callback(char *buff,uint16_t len)
{
	static mavlink_message_t mavlink_msg;
	static mavlink_status_t status;
	for (int i = 0; i < len; ++i) {
        if (mavlink_parse_char(MAVLINK_COMM_0, buff[i], &mavlink_msg, &status)){
			switch (mavlink_msg.msgid) {
			case 204:
			{
				mavlink_car_status_t car;
				mavlink_msg_car_status_decode(&mavlink_msg, &car);
				static uint32_t tick = 0;
				cout << "成功！"<< ++tick <<" "<< car.yaw <<endl;
				break;
			}
			
			
			}

		}
	}
}
int main(int argc, char *argv[])
{
	ros::init(argc, argv, "carrx_node");
    ros::NodeHandle nh;


    // 1. 开启uart
	
	port1.open("/dev/ttyACM0", SerialPort::defaultOptions);
	if (port1.isOpen())
	{
		cout << "port1 open success!" << endl;
	}
	else
	{
		cout << "port1 open failed!" << endl;
		return 0;
	}
	port1.openThread(uart_callback);
	
	// SerialPort port2;
	// SerialPort::OpenOptions uartOptions = SerialPort::defaultOptions;
	// uartOptions.baudRate = SerialPort::BR38400;
	// port2.open("/dev/ttyUSB1",uartOptions);
	// if (port2.isOpen())
	// {
	// 	cout << "port2 open success!" << endl;
	// }
	// else
	// {
	// 	cout << "port2 open failed!" << endl;
	// 	return 0;
	// }
	// port2.openThread(uart2_callback);
    //2. ros发送
    ros::Publisher pub = nh.advertise<car::car_status>("carTx", 10);
	ros::Subscriber subscriber;
	subscriber = nh.subscribe("gps/navsat", 5, &rtk_callback);
    ros::Rate rate_hz(30);
    while(ros::ok()) {
        // 初始化消息对象
        pub.publish(car_msg);
		car_msg.pitch +=1;

		mavlink_car_status_t mavlink_car_status;
		mavlink_car_status.pitch = car_msg.pitch;
		mavlink_car_status.roll = car_msg.roll;
		mavlink_car_status.yaw = car_msg.yaw;
		mavlink_car_status.px = car_msg.px;
		mavlink_car_status.py = car_msg.py;
		mavlink_car_status.pz = car_msg.pz;
		mavlink_car_status.vx = car_msg.vx;
		mavlink_car_status.vy = car_msg.vy;
		mavlink_car_status.vz = car_msg.vz;

		mavlink_msg_car_status_encode(0,0,&mavlink_msg_tx,&mavlink_car_status);
		unsigned char temp[280];
		uint8_t len = mavlink_msg_to_send_buffer(temp,&mavlink_msg_tx);
		// port2.write(temp,len);
					mavlink_hil_gps_t hil_gps;
					hil_gps.fix_type = 2;
					// hil_gps.time_usec = gps_raw_int.time_usec;
					// hil_gps.lat = gps_raw_int.lat;
					// hil_gps.lon = gps_raw_int.lon;
					// hil_gps.alt = gps_raw_int.alt;
					// hil_gps.eph = gps_raw_int.eph;
					// hil_gps.epv = gps_raw_int.epv;
					// hil_gps.vel = gps_raw_int.vel;
					// hil_gps.cog = gps_raw_int.cog;
					hil_gps.satellites_visible = UINT8_MAX;
					// hil_gps.yaw = gps_raw_int.yaw;

					// uint8_t buffer[300];
					// mavlink_msg_hil_gps_encode(1,0,&mavlink_msg_tx,&hil_gps);
					
					// len = mavlink_msg_to_send_buffer(buffer,&mavlink_msg_tx);
					// int32_t status = port1.write(buffer,len);
					// std::cout<<"status"<<std::endl;
					// printf("hil_gps TX status: %d %d\n",status,gps_raw_int.fix_type);
        ros::spinOnce();
        rate_hz.sleep();
    }
	
	//sleep(20);//Linux下单位s
	// port1.close();//关闭串口及结束线程
	port1.close();
	return 0;
}
